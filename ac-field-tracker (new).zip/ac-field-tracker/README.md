# AC Field Activity Tracker

Full app matching the 10-screen design: Dashboard, Reminders (with tabs),
Add Reminder, Reminder Alert (alarm), Follow-up, Live Tracking, Location
Details, Daily Summary, All Locations, and Profile.

## What's included

**backend/** (drop into an existing Laravel project)
- `database/migrations/` — `reminders`, `location_logs`, and a new
  migration adding `location` to `reminders`
- `app/Models/Reminder.php`, `app/Models/LocationLog.php`
- `app/Http/Controllers/Api/ReminderController.php` — CRUD + follow-up
  endpoint (note + optional photo, auto-creates the next reminder)
- `app/Http/Controllers/Api/LocationController.php` — ingests GPS points,
  clusters them into "stays", and now also returns `distance_km` and
  `tracked_minutes` for the day (powers the Dashboard/Live Tracking stat
  cards)
- `app/Http/Middleware/VerifyApiKey.php` — single shared-key auth
- `routes/api_additions.php` — routes to merge into `routes/api.php`

**mobile/** (drop into an existing Flutter project)
- `lib/theme.dart` — green color scheme matching the design
- `lib/config.dart` — API key + backend URL (the two values you set)
- `lib/models/` — `reminder.dart` (now includes `location`), `stay.dart`,
  `day_summary.dart`
- `lib/services/api_service.dart`, `alarm_service.dart` (+ snooze, +
  ringing-stream hook), `location_service.dart`
- `lib/screens/`:
  - `dashboard_screen.dart` — home tab, stat cards, today's reminders
  - `reminder_list_screen.dart` — Upcoming/Completed/All tabs, grouped by day
  - `add_reminder_screen.dart` — now has a Location field
  - `reminder_alert_screen.dart` — **new**: full-screen ringing alert with
    Snooze/Dismiss, triggered by the `alarm` package's ringing stream
  - `follow_up_screen.dart` — **new**: outcome notes, photo capture, next
    meeting date (this is what was missing before — the backend endpoint
    existed but had no screen calling it)
  - `live_tracking_screen.dart` — tracking status, distance/time stats, map
  - `location_details_screen.dart` — single stay detail with a map
  - `all_locations_screen.dart` — day's stays as map or list
  - `daily_summary_screen.dart` — restyled as a colored timeline
  - `profile_screen.dart` — settings list (see note below on Logout)
- `android_manifest_additions.xml` — permissions to merge in

## Setup

**Backend** — same as before, plus:
- One more migration to run: `2026_08_09_000001_add_location_to_reminders_table.php`

**Mobile**
1. Copy `mobile/lib/` into your Flutter project's `lib/` (overwrite existing files).
2. `flutter pub add http intl alarm geolocator permission_handler flutter_background_service flutter_map latlong2 image_picker`
3. Set `lib/config.dart` (API key + backend URL) as before.
4. Add `assets/alarm.mp3` as before.
5. Merge `android_manifest_additions.xml` into `AndroidManifest.xml` — two
   new permissions this round: `CAMERA` (follow-up photos) and `INTERNET`
   (map tiles).

## Design decisions worth knowing

- **Maps**: using free OpenStreetMap tiles via `flutter_map`, not Google
  Maps — no API key or billing account needed. Visual style is close but
  not identical to the mockup's Google-Maps look.
- **Route on the map**: Live Tracking and All Locations draw a line through
  the day's *stays* (clustered visit points), not the raw GPS trail — the
  backend doesn't expose raw points, only clustered ones. Close enough for
  "where did I go today," not a precise breadcrumb trail.
- **Place names**: still raw lat/lng everywhere (see earlier note on
  reverse geocoding) — the mockup's "Clifton Area, Karachi, Pakistan" style
  labels aren't real yet.
- **Location Details "Notes" field**: shown in the UI to match the mockup,
  but not wired to the backend — there's no `stay_notes` table. Says so
  directly in the screen.
- **Live Tracking's "Tracking Active" indicator**: local UI state, not read
  from the actual service — if permission was denied at launch, this still
  shows green/active until you visit the Track tab and toggle it. A real
  status check would need the background service to report back, which
  isn't wired up.
- **Add Reminder's "Notes" field and "Add Follow-up" toggle**: match the
  mockup visually, but neither is sent to the backend. The actual
  follow-up (notes + photo + next date) happens after the reminder fires,
  via the Follow-up screen — that part is fully wired.
- **Profile screen has no Logout**: the mockup shows one, but this app has
  no login to log out of (confirmed earlier in the project) — a Logout
  button with nothing behind it would just be confusing, so it's left out.
  The other settings rows are placeholders (tapping shows "not built yet").

## Not done yet

- Reverse geocoding (place names instead of coordinates)
- Persisting notes on a specific stay
- Real device testing of any of this — same caveat as before, no
  Flutter/emulator in this sandbox, only checked by hand
- Deployment
