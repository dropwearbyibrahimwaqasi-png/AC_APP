// Single place to set these two values — used by both api_service.dart
// and location_service.dart so they can't drift out of sync.

// Must match API_SECRET_KEY in the backend's .env (see VerifyApiKey middleware).
const String apiKey = 'REPLACE_WITH_YOUR_API_SECRET_KEY';

// Your deployed Railway backend URL, ending in /api.
const String apiBaseUrl = 'https://your-app.up.railway.app/api';
